package com.smart.simple;

public class Boss {

}
