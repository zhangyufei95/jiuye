package com.smart.ioc;

public class LiuDeHua implements GeLi {

	public void responseAsk(String saying) {
		
		System.out.println(saying);
	}
}
