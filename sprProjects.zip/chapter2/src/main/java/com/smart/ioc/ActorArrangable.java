package com.smart.ioc;

public interface ActorArrangable {
   void injectGeli(GeLi geli);
}
