package com.smart.conf;

public class LogDao {

}
