package com.smart.conf;

public class UserDao {

}
