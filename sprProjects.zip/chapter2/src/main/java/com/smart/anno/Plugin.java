package com.smart.anno;

public interface Plugin {

}
