package com.smart.anno;

import org.springframework.stereotype.Component;

@Component
public class OnePlugin implements Plugin {

}
