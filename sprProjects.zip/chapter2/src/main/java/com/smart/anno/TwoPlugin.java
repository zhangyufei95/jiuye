package com.smart.anno;

import org.springframework.stereotype.Component;

@Component
public class TwoPlugin implements Plugin {

}
