package com.smart.anno;

import org.springframework.stereotype.Repository;

@Repository
public class LogDao {

}
