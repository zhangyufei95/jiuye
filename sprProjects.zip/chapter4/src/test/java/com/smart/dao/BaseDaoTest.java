package com.smart.dao;

import org.unitils.UnitilsTestNG;
import org.unitils.spring.annotation.SpringApplicationContext;

@SpringApplicationContext( {"classpath:/applicationContext.xml" })
public class BaseDaoTest extends UnitilsTestNG{
	
}
