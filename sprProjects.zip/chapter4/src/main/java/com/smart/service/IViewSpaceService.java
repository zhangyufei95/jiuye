package com.smart.service;


import com.smart.domain.ViewSpace;

public interface IViewSpaceService {
    void addViewSpace(ViewSpace viewSpace);
}
