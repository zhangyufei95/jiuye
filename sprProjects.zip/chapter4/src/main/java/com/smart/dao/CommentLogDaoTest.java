package com.smart.dao; 

import org.junit.Test; 
import org.junit.Before; 
import org.junit.After; 

/** 
* CommentLogDao Tester. 
* 
* @author <Authors name> 
* @since <pre>ʮһ�� 4, 2012</pre> 
* @version 1.0 
*/ 
public class CommentLogDaoTest { 

@Before
public void before() throws Exception { 
} 

@After
public void after() throws Exception { 
} 


} 
