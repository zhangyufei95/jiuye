package com.smart.introduce;

public interface Monitorable {
    void setMonitorActive(boolean active);
}
