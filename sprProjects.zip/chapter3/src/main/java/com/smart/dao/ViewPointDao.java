package com.smart.dao;


public interface ViewPointDao {
    /**
     * 删除景点
     *
     * @param pointId
     */
    public void deleteViewPoint(int pointId);
}
