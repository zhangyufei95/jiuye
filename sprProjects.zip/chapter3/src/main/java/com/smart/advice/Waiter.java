package com.smart.advice;

public interface Waiter {
    void greetTo(String name);

    void serveTo(String name);
}
