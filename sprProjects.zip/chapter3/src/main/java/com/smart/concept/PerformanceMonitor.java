package com.smart.concept;

public interface PerformanceMonitor {

    void start();

    void end();

}
