package com.smart.concept;

public interface TransactionManager {
    void beginTransaction();

    void endTransaction();
}
