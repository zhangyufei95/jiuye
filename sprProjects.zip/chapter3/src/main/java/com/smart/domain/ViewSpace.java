package com.smart.domain;


public class ViewSpace {

}