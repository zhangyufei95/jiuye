package com.smart.domain;

public class User {

}
