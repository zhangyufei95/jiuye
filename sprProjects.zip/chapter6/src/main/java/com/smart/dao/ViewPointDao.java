package com.smart.dao;


import com.smart.domain.ViewPoint;

public interface ViewPointDao {
	void addViewPoint(ViewPoint viewPoint);
}
